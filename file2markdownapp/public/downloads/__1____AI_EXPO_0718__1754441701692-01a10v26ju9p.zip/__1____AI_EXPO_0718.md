## Slide 1

![Slide 1](temp/1754441701692-01a10v26ju9p-images/slide-001.png)

## Slide 2

![Slide 2](temp/1754441701692-01a10v26ju9p-images/slide-002.png)

## Slide 3

![Slide 3](temp/1754441701692-01a10v26ju9p-images/slide-003.png)

## Slide 4

![Slide 4](temp/1754441701692-01a10v26ju9p-images/slide-004.png)

## Slide 5

![Slide 5](temp/1754441701692-01a10v26ju9p-images/slide-005.png)

## Slide 6

![Slide 6](temp/1754441701692-01a10v26ju9p-images/slide-006.png)

## Slide 7

![Slide 7](temp/1754441701692-01a10v26ju9p-images/slide-007.png)

## Slide 8

![Slide 8](temp/1754441701692-01a10v26ju9p-images/slide-008.png)

## Slide 9

![Slide 9](temp/1754441701692-01a10v26ju9p-images/slide-009.png)

## Slide 10

![Slide 10](temp/1754441701692-01a10v26ju9p-images/slide-010.png)

## Slide 11

![Slide 11](temp/1754441701692-01a10v26ju9p-images/slide-011.png)

## Slide 12

![Slide 12](temp/1754441701692-01a10v26ju9p-images/slide-012.png)

## Slide 13

![Slide 13](temp/1754441701692-01a10v26ju9p-images/slide-013.png)

## Slide 14

![Slide 14](temp/1754441701692-01a10v26ju9p-images/slide-014.png)

## Slide 15

![Slide 15](temp/1754441701692-01a10v26ju9p-images/slide-015.png)

## Slide 16

![Slide 16](temp/1754441701692-01a10v26ju9p-images/slide-016.png)

## Slide 17

![Slide 17](temp/1754441701692-01a10v26ju9p-images/slide-017.png)

## Slide 18

![Slide 18](temp/1754441701692-01a10v26ju9p-images/slide-018.png)

## Slide 19

![Slide 19](temp/1754441701692-01a10v26ju9p-images/slide-019.png)

## Slide 20

![Slide 20](temp/1754441701692-01a10v26ju9p-images/slide-020.png)

## Slide 21

![Slide 21](temp/1754441701692-01a10v26ju9p-images/slide-021.png)

## Slide 22

![Slide 22](temp/1754441701692-01a10v26ju9p-images/slide-022.png)

## Slide 23

![Slide 23](temp/1754441701692-01a10v26ju9p-images/slide-023.png)

## Slide 24

![Slide 24](temp/1754441701692-01a10v26ju9p-images/slide-024.png)

## Slide 25

![Slide 25](temp/1754441701692-01a10v26ju9p-images/slide-025.png)

## Slide 26

![Slide 26](temp/1754441701692-01a10v26ju9p-images/slide-026.png)

## Slide 27

![Slide 27](temp/1754441701692-01a10v26ju9p-images/slide-027.png)